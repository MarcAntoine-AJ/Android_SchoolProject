package com.example.a1742177.prototype1;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class SignupActivity extends AppCompatActivity {
    private static final String TAG = "SignupActivity";
    private FirebaseAuth mAuth;
    private EditText nameText;
    private EditText emailText;
    private EditText passwordText;
    private Intent intentLogin;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        this.setTitle("Créer un compte");
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_signup);
         intentLogin = new Intent(this, LoginActivity.class);
        mAuth = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_signup);


    }
    public void returnLogin(View view){
        finish();
        startActivity(intentLogin);
    }
    public void signup(View view) {
        nameText = findViewById(R.id.input_name);
        EditText emailText = (EditText) findViewById(R.id.input_email);
        EditText passwordText = (EditText) findViewById(R.id.input_password);
        String email = emailText.getText().toString();
        String password = passwordText.getText().toString();





        final ProgressDialog progressDialog = new ProgressDialog(SignupActivity.this,
                R.style.AppTheme_NoActionBar);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Création du compte...");
        progressDialog.show();


        // TODO: Implement your own signup logic here.
        if((email!=null && password!=null) && password.length()>6 && isEmailValid(email)){
            mAuth.createUserWithEmailAndPassword(email,password);
            Toast.makeText(SignupActivity.this, "Création du compte réussie",
                    Toast.LENGTH_SHORT).show();
            mAuth.signInWithEmailAndPassword(email, password);
            progressDialog.cancel();
            finish();
            startActivity(intentLogin);
        }else{
            Toast.makeText(SignupActivity.this, "Échec de la création du compte, Essayez de nouveau",
                    Toast.LENGTH_SHORT).show();
            progressDialog.cancel();
        }
    }

    private boolean isEmailValid(String email) {
        //TODO: Replace this with your own logic
        return email.contains("@");
    }


    public boolean validate() {
        boolean valid = true;

        String name = nameText.getText().toString();
        String email = emailText.getText().toString();
        String password = passwordText.getText().toString();

        if (name.isEmpty() || name.length() < 3) {
            nameText.setError("Il faut au minimum 3 caractères");
            valid = false;
        } else {
            nameText.setError(null);
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailText.setError("Entrer une adresse Email valide");
            valid = false;
        } else {
            emailText.setError(null);
        }

        if (password.isEmpty() || password.length() < 4 || password.length() > 10) {
            passwordText.setError("Le mot de passe doit être entre 4 et 10 caractères");
            valid = false;
        } else {
            passwordText.setError(null);
        }

        return valid;
    }
}
