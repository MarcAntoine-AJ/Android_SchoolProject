package com.example.a1742177.prototype1;

public class Post {
    private int id;
    private String title,shortdesc;
    private String matiere;



    public Post(int id, String title, String shortdesc, String matiere) {
        this.id = id;
        this.title = title;
        this.shortdesc = shortdesc;
        this.matiere=matiere;


    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getShortdesc() {
        return shortdesc;
    }

    public String getMatiere() {
        return matiere;
    }





    public void setTitle(String title) {
        this.title = title;
    }
    public void setShortdesc(String shortdesc){
        this.shortdesc=shortdesc;
    }
}
