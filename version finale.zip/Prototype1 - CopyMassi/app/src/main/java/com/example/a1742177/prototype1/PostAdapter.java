package com.example.a1742177.prototype1;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder>{

    private Context mCtx;
    private List<Post>postList;
    public static String question;
    public static String matiere;

    public PostAdapter(Context mCtx, List<Post> postList) {
        this.mCtx = mCtx;
        this.postList = postList;
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater= LayoutInflater.from(mCtx);

        View view = inflater.inflate(R.layout.list_layout,viewGroup,false);
        PostViewHolder holder = new PostViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder postViewHolder, int i) {
        Post post = postList.get(i);
        postViewHolder.textViewTitle.setText(post.getTitle());
        postViewHolder.textViewRating.setText(String.valueOf(post.getMatiere()));
        postViewHolder.textViewDesc.setText(post.getShortdesc());


    }


    @Override
    public int getItemCount() {
        return postList.size();
    }

    class PostViewHolder extends RecyclerView.ViewHolder{

        TextView textViewTitle,textViewDesc,textViewRating;
        public PostViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewTitle=itemView.findViewById(R.id.textViewTitle);
            textViewDesc=itemView.findViewById(R.id.textViewShortDesc);
            textViewRating=itemView.findViewById(R.id.textViewRating);
            ImageButton commentButton = itemView.findViewById(R.id.commentButton);
            commentButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    question = textViewTitle.getText().toString();
                    matiere = textViewRating.getText().toString();
                    Intent intent = new Intent(mCtx,CommentActivity.class);
                    mCtx.startActivity(intent);
                }
            });

        }
    }

}
