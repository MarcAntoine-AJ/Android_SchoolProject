package com.example.a1742177.prototype1;

import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class PostActivity extends AppCompatActivity {

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Publication");
        setContentView(R.layout.activity_post);
        Button button = findViewById(R.id.postRepondre);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createPost();
            }
        });
    }

    public void createPost(){
     try{
         TextInputEditText questionView = findViewById(R.id.Question);
         String displayName = firebaseUser.getEmail();
         String question = questionView.getText().toString();
         RadioGroup radioGroup = findViewById(R.id.Group);
         int idSelected = radioGroup.getCheckedRadioButtonId();
         RadioButton radioButton=findViewById(idSelected);
         String matiere = radioButton.getText().toString();

         Map mapPost = new HashMap();
         mapPost.put("title",question);
         mapPost.put("user",displayName);
         Map mapComments = new HashMap();
         mapComments.put("title","");
         mapComments.put("user","");

         db.collection(matiere).document(question).set(mapPost);
        // db.collection(matiere).document(question).collection("comments").document().set(mapComments);

         Intent intent =  new Intent(PostActivity.this,MainActivity.class);
         finish();
         startActivity(intent);


     }catch(Exception e){

         Toast.makeText(PostActivity.this, "Erreur",Toast.LENGTH_SHORT).show();
     }



    }



}