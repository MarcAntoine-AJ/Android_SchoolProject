package com.example.a1742177.prototype1;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;


public class MenuMatiere extends AppCompatActivity {

    public static String matiere;
    private DrawerLayout drawerLayout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setTitle("Accueil");
        setContentView(R.layout.activity_menu_matiere);


        drawerLayout = findViewById(R.id.drawer_layout);

        NavigationView navigationView = findViewById(R.id.nav_view);
       navigationView.setNavigationItemSelectedListener(
               new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        // set item as selected to persist highlight
                        menuItem.setChecked(true);
                       // close drawer when item is tapped
                        drawerLayout.closeDrawers();

                        int id = menuItem.getItemId();
                        if (id == R.id.mnuDeco) {
                            Intent intentLogin = new Intent(MenuMatiere.this, LoginActivity.class);
                           FirebaseAuth.getInstance().signOut();
                           finish();
                            startActivity(intentLogin);


                        } else if (id == R.id.mnuOptions) {
                            Intent intentOptions = new Intent(MenuMatiere.this, SettingsActivity.class);
                           finish();
                            startActivity(intentOptions);

                        } else if (id == R.id.mnuAccueil) {
                           Intent intentAccueil = new Intent(MenuMatiere.this, MenuMatiere.class);

                           finish();
                            startActivity(intentAccueil);
                        } else if (id == R.id.mnuMatieres) {
                            Intent intentMatieres = new Intent(MenuMatiere.this, MenuMatiere.class);

                           finish();
                           startActivity(intentMatieres);
                        }
                        drawerLayout.closeDrawer(GravityCompat.START);


                     return true;
                 }
                });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setHomeAsUpIndicator(R.drawable.ic_menu_white_24dp);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

//   @Override
//  public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
//       int id = menuItem.getItemId();
//      if (id == R.id.mnuDeco) {
//            Intent intentLogin = new Intent(this, LoginActivity.class);
//           FirebaseAuth.getInstance().signOut();
//          finish();
//          startActivity(intentLogin);
//
//
//      } else if (id == R.id.mnuOptions) {
//          Intent intentOptions = new Intent(this, SettingsActivity.class);
//           finish();
//          startActivity(intentOptions);
//
//      } else if (id == R.id.mnuAccueil) {
//           Intent intentAccueil = new Intent(this, MenuMatiere.class);
//
//          finish();
//           startActivity(intentAccueil);
//      } else if (id == R.id.mnuMatieres) {
//           Intent intentMatieres = new Intent(this, MenuMatiere.class);
//
//            finish();
//            startActivity(intentMatieres);
//       }
//        drawerLayout.closeDrawer(GravityCompat.START);
//        return true;
//   }

    public void Post_new(View view) {

        Intent myIntent = new Intent(MenuMatiere.this, PostActivity.class);


        startActivity(myIntent);

    }


    public void B_Math(View view) {
        matiere = "Maths";


        Intent myIntent = new Intent(MenuMatiere.this, MainActivity.class);


        MenuMatiere.this.startActivity(myIntent);

    }

    public void B_Phyisique(View view) {
        matiere = "Physique";

        Intent myIntent = new Intent(MenuMatiere.this, MainActivity.class);


        MenuMatiere.this.startActivity(myIntent);

    }

    public void B_Chimie(View view) {
        matiere = "Chimie";

        Intent myIntent = new Intent(MenuMatiere.this, MainActivity.class);


        MenuMatiere.this.startActivity(myIntent);

    }

    public void B_Biologie(View view) {
        matiere = "Biologie";

        Intent myIntent = new Intent(MenuMatiere.this, MainActivity.class);


        MenuMatiere.this.startActivity(myIntent);

    }

    public void B_Economie(View view) {
        matiere = "Économie";

        Intent myIntent = new Intent(MenuMatiere.this, MainActivity.class);


        MenuMatiere.this.startActivity(myIntent);

    }

    public void B_Francais(View view) {
        matiere = "Français";

        Intent myIntent = new Intent(MenuMatiere.this, MainActivity.class);


        MenuMatiere.this.startActivity(myIntent);

    }


}
