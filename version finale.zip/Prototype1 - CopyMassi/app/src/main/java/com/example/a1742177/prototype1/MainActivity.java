package com.example.a1742177.prototype1;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    int i = 1;
    private static final String TAG = "Data";
    private static final String TAG2 = "ZIBBBBBBBB";
    private static final String TAG3 = "kesss emak";


    ArrayList<String> listeInfos= new ArrayList<>();
    ArrayList<String> listeTitre= new ArrayList<>();
    ArrayList<String> listeUser= new ArrayList<>();


    FirebaseFirestore db = FirebaseFirestore.getInstance();

    FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
    private DrawerLayout drawer;
    RecyclerView recyclerView;
    PostAdapter adapter;
    List<Post> postList;




    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setTitle(MenuMatiere.matiere);

      //  mAuth = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        writeData();
        getDataPosts();
        setListenersDataBase();

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,PostActivity.class);
                startActivity(intent);
            }
        });

         drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        recyclerView=(RecyclerView)findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        postList= new ArrayList<>();
        addDansLaListe();





    }
    public void setListenersDataBase()
    {
        db.collection("Maths").addSnapshotListener(new EventListener<QuerySnapshot>() {
        @Override
        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
            if (e != null) {
                Log.w("KISS EMAK", "listen:error", e);
                return;
            }
           getDataPosts();
            Log.d("BONJOUR DATA CHANGER : ","plz");
        }
    });

    }
    public void addDansLaListe(){

        postList.add(

                new Post(1,"","",MenuMatiere.matiere)


        );


        //creating recyclerview adapter
        PostAdapter adapter = new PostAdapter(this, postList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);


    }

    public void updateTitle(){
        int i =0;
        int j=0;
        try{
            for(i =0;i<listeTitre.size() && i<postList.size();i++){
                postList.get(i).setTitle(listeTitre.get(i));
                postList.get(i).setShortdesc(listeUser.get(i));
                recyclerView.getAdapter().notifyItemChanged(i);
            }
            if(postList.size()<listeTitre.size()){
                for( j =0;j<(listeTitre.size()-postList.size());i++){
                    postList.add(
                            new Post(
                                    1,
                                    listeTitre.get(i+j),
                                    listeUser.get(i+j),
                                    MenuMatiere.matiere));

                }


            }


        }catch(Exception e){
            e.printStackTrace();
        }


    }


    public void getDataPosts(){
        db.collection(MenuMatiere.matiere)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        ArrayList<String> listeTitre = new ArrayList<>();
                        ArrayList<String> listeUser = new ArrayList<>();

                        if (task.isSuccessful()) {

                            for (QueryDocumentSnapshot document : task.getResult()) {

                                Log.d(TAG, document.getId() + " => " + document.getData().get("title"));
                                listeTitre.add(document.getData().get("title").toString());
                                listeUser.add(document.getData().get("user").toString());
                                Log.d(TAG2, "" + listeTitre.get(0));


                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                        storeDataTitre(listeTitre);
                        storeDataUser(listeUser);
                        updateTitle();
                    }
                });
    }


    public void getDataUsers() {




        db.collection("users")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        ArrayList<String> listeEmail = new ArrayList<>();
                        if (task.isSuccessful()) {

                            for (QueryDocumentSnapshot document : task.getResult()) {

                                Log.d(TAG, document.getId() + " => " + document.getData().get("email"));
                                listeEmail.add(document.getData().get("email").toString());
                                Log.d(TAG2, "" + listeEmail.get(0));


                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                        storeDataEmail(listeEmail);
                    }
                });
    }
    public void storeDataEmail(ArrayList<String> liste){
        listeInfos=liste;

    }
    public void storeDataTitre(ArrayList<String> liste){
        listeTitre=liste;

    }
    public void storeDataUser(ArrayList<String> liste){
        listeUser=liste;

    }


   /* @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
       updateUI(currentUser);
    }
    */
    /*public void updateUI(FirebaseUser user){

    }*/

   /* public void createAccount(String email,String password){
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("tizz","signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("ayr", "signInWithEmail:failure", task.getException());
                            Toast.makeText(EmailPasswordActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }

                        // ...
                    }
                });

    }***/

    @Override
    public void onBackPressed() {

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    public void writeData(){

        // Create a new user with a first and last name

// Add a new document with a generated ID
        db.collection("users")
                .document(firebaseUser.getUid()).set(firebaseUser);
           /*     .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error adding document", e);
                    }
                });*/
        try{
db.collection("users").document(firebaseUser.getUid()).update("displayName","456");

        }catch(Exception e){
            e.printStackTrace();
        };


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();
        if(id == R.id.mnuDeco){
            Intent intentLogin = new Intent(this, LoginActivity.class);
            FirebaseAuth.getInstance().signOut();
            finish();
            startActivity(intentLogin);


        }
        else if(id == R.id.mnuOptions){
            Intent intentOptions = new Intent(this, SettingsActivity.class);
            finish();
            startActivity(intentOptions);

        }    else if(id == R.id.mnuAccueil) {
            Intent intentAccueil = new Intent(this, MenuMatiere.class);

            finish();
            startActivity(intentAccueil);
        }
        else if(id == R.id.mnuMatieres) {
            Intent intentMatieres = new Intent(this, MenuMatiere.class);

            finish();
            startActivity(intentMatieres);
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
