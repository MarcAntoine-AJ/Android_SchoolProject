package com.example.a1742177.prototype1;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class EcrireCommentActivity extends AppCompatActivity {

    EditText editText;
    Button button;
    String question;
    String matiere;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecrire_comment);
        editText=findViewById(R.id.editTextComment);
        button = findViewById(R.id.postComment);
        question= PostAdapter.question;
        matiere=PostAdapter.matiere;
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ecrireComment();
            }
        });
    }

    public void ecrireComment(){


          String comment =editText.getText().toString();
          String user = FirebaseAuth.getInstance().getCurrentUser().getEmail();
          Map mapComment = new HashMap();
          mapComment.put("title",comment);
          mapComment.put("user",user);


if(comment.equals("")){

    Toast.makeText(EcrireCommentActivity.this, "Erreur",Toast.LENGTH_SHORT).show();

}else{
    db.collection(matiere).document(question).collection("comments").document().set(mapComment);

    Intent intent =  new Intent(EcrireCommentActivity.this,CommentActivity.class);
    finish();
    startActivity(intent);

}






    }
}
