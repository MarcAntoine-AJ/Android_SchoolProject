package com.example.a1742177.prototype1;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

public class CommentActivity extends AppCompatActivity {
    List<Comments> commentsList;
    String question ;

    private static final String TAG = "Comments my G";

    private static final String TAG2 = "Happy christmas";

    //the recyclerview
    RecyclerView recyclerView;
    TextView questionRepondre;

    ArrayList<String> listeTitre= new ArrayList<>();
    ArrayList<String> listeUser= new ArrayList<>();
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Question");
        setContentView(R.layout.activity_comment);
        Toolbar toolbar = findViewById(R.id.tool);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        question = PostAdapter.question;

        FloatingActionButton fab = findViewById(R.id.fab);

        questionRepondre = findViewById(R.id.PostRepondre);
        questionRepondre.setText(question);
        getDataPosts();
        setListenersDataBase();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(CommentActivity.this,EcrireCommentActivity.class);
                finish();
                startActivity(intent);
            }
        });
        //getting the recyclerview from xml
        recyclerView = (RecyclerView) findViewById(R.id.recyclerComments);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //initializing the productlist
        commentsList = new ArrayList<>();


        //adding some items to our list
        commentsList.add(
                new Comments(1, "", ""));


        //creating recyclerview adapter
        CommentsAdapter commentsAdapter = new CommentsAdapter(this, commentsList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(commentsAdapter);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }


    public void getDataPosts(){
        db.collection(MenuMatiere.matiere).document(question).collection("comments")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        ArrayList<String> listeTitre = new ArrayList<>();
                        ArrayList<String> listeUser = new ArrayList<>();

                        if (task.isSuccessful()) {

                            for (QueryDocumentSnapshot document : task.getResult()) {

                                Log.d(TAG, document.getId() + " => " + document.getData().get("title"));
                                listeTitre.add(document.getData().get("title").toString());
                                listeUser.add(document.getData().get("user").toString());
                                Log.d(TAG2, "" + listeTitre.get(0));


                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                        storeDataTitre(listeTitre);
                        storeDataUser(listeUser);
                        updateTitle();
                    }
                });
    }

    public void updateTitle(){
        int i =0;
        int j=0;
        try{
            for(i =0;i<listeTitre.size() && i<commentsList.size();i++){

                    commentsList.get(i).setTitle(listeTitre.get(i));
                    commentsList.get(i).setShortdesc(listeUser.get(i));
                    recyclerView.getAdapter().notifyItemChanged(i);


            }
            if(commentsList.size()<listeTitre.size()){
                for( j =0;j<(listeTitre.size()-commentsList.size());i++){
                    commentsList.add(
                            new Comments(
                                    1,
                                    listeTitre.get(i+j),
                                    listeUser.get(i+j)));


                }



            }


        }catch(Exception e){
            e.printStackTrace();
        }


    }

    public void storeDataTitre(ArrayList<String> liste){
        listeTitre=liste;

    }
    public void storeDataUser(ArrayList<String> liste){
        listeUser=liste;

    }
    public void setListenersDataBase()
    {
        db.collection(MenuMatiere.matiere).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w("KISS EMAK", "listen:error", e);
                    return;
                }
                getDataPosts();
                Log.d("BONJOUR DATA CHANGER : ","plz");
            }
        });

    }


}







